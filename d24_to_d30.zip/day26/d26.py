# with open("file1.txt") as f1:
#     lst=f1.readlines()
# with open("file2.txt") as f2:
#     lst2=f2.readlines()
# result=[int(i) for i in lst if i in lst2 ]
#
# # Write your code above 👆
#
# print(result)

#dict comprihansion
# import random
# name=['nan','cokko','tokaa','almigh','hanzo','loko']
# student_score={key:random.randint(40,100) for key in name}
# print(student_score)
# passed={key:student_score[key] for key in student_score if student_score[key]>=60}
# print(passed)
# passed={key:value for (key,value) in student_score.items() if value>=60}
# print(passed)
#QUIZ1
# sentence = "What is the Airspeed Velocity of an Unladen Swallow?"
# # Don't change code above 👆
#
# # Write your code below:
# result={key:len(key) for key in sentence.split()}
#
# print(result)
#quiz 2
# Dictionary Comprehension 2
# Instructions
# You are going to use Dictionary Comprehension to create a dictionary called weather_f that takes each temperature in degrees Celsius and converts it into degrees Fahrenheit.
#
# To convert temp_c into temp_f:
# (temp_c * 9/5) + 32 = temp_f
# Do NOT Create a dictionary directly. Try to use Dictionary Comprehension instead of a Loop.
#
# Example Output
# {
# 'Monday': 53.6,
# 'Tuesday': 57.2,
# 'Wednesday': 59.0,
# 'Thursday': 57.2,
# 'Friday': 69.8,
# 'Saturday': 71.6,
# 'Sunday': 75.2
# # }
# weather_c = {
#     "Monday": 12,
#     "Tuesday": 14,
#     "Wednesday": 15,
#     "Thursday": 14,
#     "Friday": 21,
#     "Saturday": 22,
#     "Sunday": 24,
# }
# # 🚨 Don't change code above 👆
# # Write your code 👇 below:
# weather_f={key:value*(9/5)+32 for (key,value) in weather_c.items()}
# print(weather_f)
# student_dict={"studen":['dshd','sdajhsa','skaldh'],"score":[12,43,21]}
# import pandas
# std_datafram=pandas.DataFrame(student_dict)
#print(std_datafram)
#
# for (key,value) in std_datafram.items():
#     print(value)
#pandas in built loop
# for (index,row) in std_datafram.iterrows():
#     print(row.score)
#name define generator
import pandas
data=pandas.read_csv("nato_phonetic_alphabet.csv")
dict_data={row.letter:row.code for (index,row) in data.iterrows()}
print(dict_data)
name=input("enter you name : ").upper()
name_list=[dict_data[char] for char in name]
print(name_list)
