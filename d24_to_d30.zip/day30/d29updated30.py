import tkinter as t
from tkinter import messagebox
import random
import pyperclip
import json
# ---------------------------- PASSWORD GENERATOR ------------------------------- #

def generator():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
               'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    passl = []
    [passl.append(random.choice(letters)) for i in range(nr_letters)]
    [passl.append(random.choice(numbers)) for i in range(nr_numbers)]
    [passl.append(random.choice(symbols)) for i in range(nr_symbols)]

    random.shuffle(passl)
    pawd = ''.join(passl)
    passinp.delete(0,t.END)
    passinp.insert(0,pawd)

# ---------------------------- SAVE PASSWORD ------------------------------- #
def add():


    wb=webinp.get()
    em=emailinp.get()
    ps=passinp.get()
    dict={
        wb: {
                "email":em,
                "password":ps
        }
    }
    if len(wb)>0 and len(ps) >0:
        pyperclip.copy(ps)
        try:
            with open("data.json", "r") as file:
                read=json.load(file)
        except FileNotFoundError:
            with open("data.json","w") as file:
                json.dump(dict,file,indent=4)
        else:

            read.update(dict)
            with open("data.json","w") as file:
                json.dump(read,file,indent=4)



        webinp.delete(0, t.END)
        emailinp.delete(0, t.END)
        emailinp.insert(0, "akarshitg99@gmail.com")
        passinp.delete(0, t.END)

    else:
        messagebox.showinfo(title="Opps",message="Please dont left any feild empty !")
#-----------------------------SEARCH__________________________________#
def Search():
    try:
        with open("data.json") as read:
            alldata=json.load(read)
    except FileNotFoundError:
        messagebox.showinfo(title="No entry",message="please do entry first ")
    else:
        srch=webinp.get()
        if srch in alldata:
            messagebox.showinfo(title=srch,message=f"Email:{alldata[srch]['email']}\nPassword:{alldata[srch]['password']}")
        else:
            messagebox.showinfo(title="Error!",message="No data found")
# ---------------------------- UI SETUP ------------------------------- #

screen=t.Tk()
screen.config(padx=50,pady=50)
screen.title("Password Manager")

canvas=t.Canvas(height=200,width=200)
img=t.PhotoImage(file="logo.png")
canvas.create_image(100,100,image=img)
canvas.grid(row=0,column=1)
#lebels
web=t.Label(text="Website:")
web.grid(row=1,column=0)
email=t.Label(text="Email/Username:")
email.grid(row=2,column=0)
password=t.Label(text="Password:")
password.grid(row=3,column=0)
#input

webinp=t.Entry(width=28)
webinp.grid(row=1,column=1)
webinp.focus()
emailinp=t.Entry(width=49)
emailinp.insert(0,"akarshitg99@gmail.com")
emailinp.grid(row=2,column=1,columnspan=2)
passinp=t.Entry(width=28)
passinp.grid(row=3,column=1)
#buttons
src=t.Button(text="Search",width=17,command=Search)
src.grid(row=1,column=2)
gen=t.Button(text="Generate Password",command=generator)
gen.grid(row=3,column=2)
add=t.Button(text="Add",width=46,command=add)
add.grid(row=4,column=1,columnspan=2)


screen.mainloop()