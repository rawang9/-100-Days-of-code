from turtle import Screen,Turtle
import pandas
from name_tur import Tur
bg=Turtle()
screen=Screen()
screen.title("the US_state_Quiz")
img='blank_states_img.gif'
screen.addshape(img)
bg.shape(img)
tim=Tur()
data=pandas.read_csv("50_states.csv")
state=data["state"].to_list()
print(state)
count=[]
g=data[data.state=='Iowa']
while len(count)<50:
    guess=screen.textinput(f"{len(count) }/50 Guess thes state","Try onother one").title()
    if guess in state:
        final=data[data.state==guess]
        tim.create(guess,int(final.x),int(final.y))
        count.append(guess)

    elif guess=='Exit':
        break

#state_to_learn.csv
miss=[]
[miss.append(i) for i in state if i not in count]
dict={'state to learn' : miss}
data=pandas.DataFrame(dict)
data.to_csv("state_to_learn.csv")