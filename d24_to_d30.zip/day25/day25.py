# import csv
# with open("wether.csv") as data:
#     line=csv.reader(data)
#     temp=[]
#     for row in line:
#         if row[1]!='temp':
#             temp.append(int(row[1]))
#
#
# # print(temp)
# import pandas
# data=pandas.read_csv("wether.csv")
# list_data=data["temp"].to_list()
# print(sum(list_data)/len(list_data))

import pandas
#data=pandas.read_csv("wether.csv")
#print(data["temp"].max())
#data.temp works same as data["temp"]
#adding condition for a specific row
#print(data.temp)
#print(data)
#print(data[data.temp==data.temp.max()])
#print(data.condition[data.temp==data.temp.max()])

#print the condition on max temp
#print(data.condition[data.temp==data.temp.max()])
#monday=data[data.day=='Monday']

#for converting it to farenh
#print(float((monday.temp*(9/5))+32),'Far')

# data_dict={'Name':['rma','shyama','puja'],'score':[12,32,43]}
# data=pandas.DataFrame(data_dict)
#creating a csv file using pandas
#data.to_csv("panda_create.csv")

#counting the squaral of 2018
data=pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")
black=data[data["Primary Fur Color"]=='Black']
total_black=len(black["Primary Fur Color"].tolist())
Cinnamon=data[data["Primary Fur Color"]=='Cinnamon']
total_Cinnamon=len(Cinnamon["Primary Fur Color"].tolist())
Gray=data[data["Primary Fur Color"]=='Gray']
total_Gray=len(Gray["Primary Fur Color"].tolist())
dir_data={'Fur Color':['Gray','Cinnamon','Black'],'Count':[total_Gray,total_Cinnamon,total_black]}
new_doc=pandas.DataFrame(dir_data)
new_doc.to_csv("Color_data.csv")

