from turtle import Turtle
import random
COLOR=["red","orange","yellow","green","blue","purple"]
class Tur():
    def __init__(self):
        self.timy=[]
    def create(self,arg,x,y):
        tim=Turtle("circle")
        tim.color(random.choice(COLOR))
        tim.shapesize(0.25,0.25)
        tim.up()
        tim.goto(x,y)
        tim.down()
        tim.write(arg, move=False, align="left", font=("Arial", 15, "normal"))

