import tkinter as tk
screen=tk.Tk()
screen.title("Mile to Km Coverter")
screen.config(padx=10,pady=10)
#inputbox
minput=tk.Entry(width=10)
minput.grid(row=0,column=1)
#lebel
mleb=tk.Label(text="Miles")
mleb.grid(row=0,column=2)

iseql=tk.Label(text="is equal to")
iseql.grid(row=1,column=0)

km=tk.Label(text="km")
km.grid(row=1,column=2)
#button
def cal():
    mile_to_km=float(minput.get())*1.609
    mtok=tk.Label(text=f"{mile_to_km}")
    mtok.grid(row=1,column=1)
but=tk.Button(text="Calculate",command=cal)
but.grid(row=2,column=1)

screen.mainloop()