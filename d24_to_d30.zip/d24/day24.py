# with open("../../d24.txt",'r') as data:
#     print(data.read())
with open("latter_formate.txt",'r') as fmate:
    form=fmate.read()

with open("name.txt",'r') as name:
    naam=name.read().split()
for nm in naam:
    msg=form.replace('[name]',nm)
    with open(f"./latters/letter_for_{nm}.txt",'w') as creat:
        creat.write(msg)
